module.exports.avatarsURL = [
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920047/avatar/burger_wulqe4.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920047/avatar/polar_oyhdx2.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920047/avatar/astronaut_hcvecf.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920047/avatar/unicorn_uwwsro.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920046/avatar/chicken_kqgsjp.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920046/avatar/shiba_q4arja.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920047/avatar/penguin_zomskk.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920047/avatar/piggy_s8eq7m.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920047/avatar/cow_ztmhnw.webp",
	"https://res.cloudinary.com/quoteequotesid/image/upload/v1630920047/avatar/dino_er8gja.webp"
];
